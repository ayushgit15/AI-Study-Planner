import { CalendarRange, Flag, RefreshCw, TrendingUp } from "lucide-react";

export const landingNavLinks = [
  { label: "Features", href: "#features" },
  { label: "How it works", href: "#how-it-works" },
];

export const features = [
  {
    id: "personalized-planning",
    icon: CalendarRange,
    title: "Personalized Planning",
    description:
      "Add your exam dates, subjects and daily study hours. StudyPilot builds a day-by-day schedule that fits your actual week.",
    visual: {
      type: "inputs",
      chips: [
        { label: "Exam", value: "Thu, 8 Oct" },
        { label: "Study time", value: "3 hrs/day" },
        { label: "Subjects", value: "4" },
        { label: "Weak spot", value: "Normalization" },
      ],
    },
  },
  {
    id: "adaptive-scheduling",
    icon: RefreshCw,
    title: "Adaptive Scheduling",
    description:
      "Missed a session or finished early? The plan rebalances the remaining days so nothing important gets dropped.",
    visual: {
      type: "reschedule",
      from: { title: "Normalization practice", when: "Friday", tag: "Missed", tone: "danger" },
      to: { title: "Normalization practice", when: "Tuesday", tag: "Moved", tone: "accent" },
    },
  },
  {
    id: "smart-priorities",
    icon: Flag,
    title: "Smart Priorities",
    description:
      "Rate each topic's difficulty, your confidence and its weight in the exam. Weak, high-stakes topics get more time and earlier slots.",
    visual: {
      type: "priorities",
      items: [
        { topic: "Normalization", note: "Hard, low confidence", level: "High" },
        { topic: "Transactions", note: "Medium, some confidence", level: "Medium" },
        { topic: "ER diagrams", note: "Easy, high confidence", level: "Low" },
      ],
    },
  },
  {
    id: "progress-tracking",
    icon: TrendingUp,
    title: "Progress Tracking",
    description:
      "See completed hours, topic coverage and confidence per subject, so you know where you stand well before exam week.",
    visual: {
      type: "weekly",
      maxHours: 4,
      caption: "Hours studied this week",
      days: [
        { day: "M", name: "Monday", done: 3, planned: 3 },
        { day: "T", name: "Tuesday", done: 3, planned: 3 },
        { day: "W", name: "Wednesday", done: 2.5, planned: 3 },
        { day: "T", name: "Thursday", done: 3, planned: 3 },
        { day: "F", name: "Friday", done: 0, planned: 3 },
        { day: "S", name: "Saturday", done: 1.4, planned: 3.5 },
        { day: "S", name: "Sunday", done: 0, planned: 2 },
      ],
    },
  },
];

export const howItWorksSteps = [
  {
    title: "Tell us what you're studying",
    description:
      "Enter your exam dates, subjects and topics, plus how many hours you can study each day. Rate every topic on difficulty, your confidence and importance.",
  },
  {
    title: "Get your personalized plan",
    description:
      "StudyPilot spreads your topics across the days you have, giving weaker and higher-stakes topics more time and earlier slots.",
  },
  {
    title: "Let the plan adapt to you",
    description:
      "Mark tasks as done or skipped. When you fall behind or get ahead, the rest of the schedule is rebalanced for you.",
  },
];
