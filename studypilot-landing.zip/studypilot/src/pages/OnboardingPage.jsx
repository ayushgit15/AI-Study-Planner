import PageHeader from "@/components/layout/PageHeader.jsx";
import PagePlaceholder from "@/components/layout/PagePlaceholder.jsx";
import Button from "@/components/ui/Button.jsx";

export default function OnboardingPage() {
  return (
    <>
      <PageHeader
        title="Create your study plan"
        description="Basic information, subjects and topics will be collected here, one step at a time."
      />
      <PagePlaceholder>The step-by-step form is built in the onboarding step.</PagePlaceholder>
      <div className="mt-6 flex justify-end">
        <Button to="/dashboard">Skip to dashboard</Button>
      </div>
    </>
  );
}
