import { Outlet } from "react-router-dom";
import { X } from "lucide-react";
import Logo from "@/components/ui/Logo.jsx";
import Button from "@/components/ui/Button.jsx";

/** Focused shell for the plan-creation flow: no app navigation, just a way out. */
export default function OnboardingLayout() {
  return (
    <div className="min-h-dvh">
      <header className="mx-auto flex h-16 w-full max-w-3xl items-center justify-between px-4 sm:px-6">
        <Logo />
        <Button to="/" variant="ghost" size="sm" aria-label="Exit plan creation">
          <X size={16} aria-hidden="true" />
          Exit
        </Button>
      </header>

      <main className="mx-auto w-full max-w-3xl px-4 pb-16 pt-6 sm:px-6 sm:pt-10">
        <Outlet />
      </main>
    </div>
  );
}
