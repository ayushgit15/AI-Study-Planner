import PreviewCard from "./PreviewCard.jsx";
import ProgressRing from "@/components/ui/ProgressRing.jsx";

export default function TodayProgressCard({ tasksDone, tasksTotal, studied, planned }) {
  const percent = Math.round((tasksDone / tasksTotal) * 100);

  return (
    <PreviewCard title="Today's progress">
      <div className="flex items-center gap-4">
        <ProgressRing value={percent} delay={500}>
          <span className="text-sm font-semibold tabular-nums">{percent}%</span>
        </ProgressRing>
        <div>
          <p className="text-[13px] font-medium">
            {tasksDone} of {tasksTotal} tasks done
          </p>
          <p className="mt-0.5 text-xs text-ink-muted">
            {studied} of {planned}
          </p>
        </div>
      </div>
    </PreviewCard>
  );
}
