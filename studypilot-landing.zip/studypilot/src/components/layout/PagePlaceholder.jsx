import { Hammer } from "lucide-react";
import Card from "@/components/ui/Card.jsx";

/** Temporary body for pages that are built in later steps. Delete once every page is real. */
export default function PagePlaceholder({ children = "This page is built in a later step." }) {
  return (
    <Card className="flex min-h-64 flex-col items-center justify-center gap-3 border-dashed text-center">
      <span className="flex size-10 items-center justify-center rounded-full bg-accent-soft text-accent">
        <Hammer size={18} aria-hidden="true" />
      </span>
      <p className="max-w-sm text-sm text-ink-muted">{children}</p>
    </Card>
  );
}
