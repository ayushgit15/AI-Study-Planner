import PreviewCard from "./PreviewCard.jsx";
import ProgressBar from "@/components/ui/ProgressBar.jsx";

export default function OverallCompletionCard({ percent, hoursDone, hoursTotal, status }) {
  return (
    <PreviewCard
      title="Overall completion"
      action={
        <span className="rounded-full bg-success-soft px-2 py-0.5 text-[11px] font-medium text-success">{status}</span>
      }
    >
      <p className="text-3xl font-semibold leading-none tracking-tight tabular-nums">{percent}%</p>
      <ProgressBar value={percent} delay={550} className="mt-4" />
      <p className="mt-2.5 text-xs text-ink-muted">
        {hoursDone} of {hoursTotal} study hours
      </p>
    </PreviewCard>
  );
}
