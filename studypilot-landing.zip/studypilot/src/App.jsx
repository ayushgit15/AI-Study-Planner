import { Route, Routes } from "react-router-dom";

import MarketingLayout from "@/layouts/MarketingLayout.jsx";
import OnboardingLayout from "@/layouts/OnboardingLayout.jsx";
import AppLayout from "@/layouts/AppLayout.jsx";

import LandingPage from "@/pages/LandingPage.jsx";
import OnboardingPage from "@/pages/OnboardingPage.jsx";
import DashboardPage from "@/pages/DashboardPage.jsx";
import StudyPlanPage from "@/pages/StudyPlanPage.jsx";
import ProgressPage from "@/pages/ProgressPage.jsx";
import SettingsPage from "@/pages/SettingsPage.jsx";
import NotFoundPage from "@/pages/NotFoundPage.jsx";

export default function App() {
  return (
    <Routes>
      <Route element={<MarketingLayout />}>
        <Route index element={<LandingPage />} />
      </Route>

      <Route element={<OnboardingLayout />}>
        <Route path="onboarding" element={<OnboardingPage />} />
      </Route>

      <Route element={<AppLayout />}>
        <Route path="dashboard" element={<DashboardPage />} />
        <Route path="study-plan" element={<StudyPlanPage />} />
        <Route path="progress" element={<ProgressPage />} />
        <Route path="settings" element={<SettingsPage />} />
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}
