import { NavLink } from "react-router-dom";
import { appNavItems } from "@/data/navigation.js";
import { cn } from "@/lib/cn.js";
import Logo from "@/components/ui/Logo.jsx";
import UserChip from "@/components/layout/UserChip.jsx";

export default function Sidebar() {
  return (
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-line bg-surface px-4 py-6 lg:flex">
      <Logo to="/dashboard" className="px-2" />

      <nav aria-label="Main" className="mt-10 flex flex-1 flex-col gap-1">
        {appNavItems.map(({ label, to, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 rounded-control px-3 py-2.5 text-[15px] font-medium transition-colors duration-150",
                isActive ? "bg-accent-soft text-accent" : "text-ink-muted hover:bg-canvas hover:text-ink",
              )
            }
          >
            <Icon size={18} aria-hidden="true" />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="border-t border-line px-2 pt-5">
        <UserChip />
      </div>
    </aside>
  );
}
