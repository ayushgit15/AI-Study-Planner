import Logo from "@/components/ui/Logo.jsx";
import Button from "@/components/ui/Button.jsx";

export default function NotFoundPage() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-6 px-4 text-center">
      <Logo />
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">We couldn't find that page</h1>
        <p className="mt-2 text-ink-muted">The link may be out of date, or the page may have moved.</p>
      </div>
      <Button to="/">Back to home</Button>
    </div>
  );
}
