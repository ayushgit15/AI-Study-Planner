export const mockUser = {
  name: "Aanya Sharma",
  detail: "B.Tech, 3rd year",
  initials: "AS",
};
