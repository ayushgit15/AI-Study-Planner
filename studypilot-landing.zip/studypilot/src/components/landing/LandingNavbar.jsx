import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import Container from "@/components/ui/Container.jsx";
import Logo from "@/components/ui/Logo.jsx";
import Button from "@/components/ui/Button.jsx";
import MobileNavPanel from "./MobileNavPanel.jsx";
import { landingNavLinks } from "@/data/landingContent.js";

export default function LandingNavbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  // Close the mobile menu with Escape
  useEffect(() => {
    if (!menuOpen) return;
    const onKeyDown = (event) => event.key === "Escape" && setMenuOpen(false);
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [menuOpen]);

  return (
    <header className="sticky top-0 z-40 border-b border-line/70 bg-canvas/85 backdrop-blur">
      <Container className="flex h-16 items-center justify-between">
        <Logo />

        <div className="hidden items-center gap-1 md:flex">
          <nav aria-label="Page sections" className="flex items-center">
            {landingNavLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="rounded-control px-3 py-2 text-sm font-medium text-ink-muted transition-colors duration-150 hover:text-ink"
              >
                {link.label}
              </a>
            ))}
          </nav>
          {/* Auth isn't built yet, so Sign in goes to the demo dashboard for now. */}
          <Button to="/dashboard" variant="ghost" size="sm">
            Sign in
          </Button>
          <Button to="/onboarding" size="sm" className="ml-1">
            Create Study Plan
          </Button>
        </div>

        <button
          type="button"
          onClick={() => setMenuOpen((open) => !open)}
          aria-expanded={menuOpen}
          aria-controls="mobile-nav"
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          className="inline-flex size-10 items-center justify-center rounded-control text-ink transition-colors hover:bg-black/5 md:hidden"
        >
          {menuOpen ? <X size={20} aria-hidden="true" /> : <Menu size={20} aria-hidden="true" />}
        </button>
      </Container>

      {menuOpen && <MobileNavPanel id="mobile-nav" links={landingNavLinks} onNavigate={() => setMenuOpen(false)} />}
    </header>
  );
}
