import { Outlet } from "react-router-dom";
import LandingNavbar from "@/components/landing/LandingNavbar.jsx";
import LandingFooter from "@/components/landing/LandingFooter.jsx";

/** Shell for public pages (landing). */
export default function MarketingLayout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <LandingNavbar />
      <main className="flex-1">
        <Outlet />
      </main>
      <LandingFooter />
    </div>
  );
}
