import { cn } from "@/lib/cn.js";

/** Fades and lifts its children in on page load. `delay` is in ms. */
export default function FadeUp({ as: Tag = "div", delay = 0, className = "", children }) {
  return (
    <Tag className={cn("animate-fade-up", className)} style={{ animationDelay: `${delay}ms` }}>
      {children}
    </Tag>
  );
}
