import { cn } from "@/lib/cn.js";

const paddings = {
  none: "",
  sm: "p-4",
  md: "p-5 sm:p-6",
  lg: "p-6 sm:p-8",
};

export default function Card({ as: Tag = "div", padding = "md", className = "", children, ...props }) {
  return (
    <Tag
      className={cn("rounded-card border border-line bg-surface shadow-card", paddings[padding], className)}
      {...props}
    >
      {children}
    </Tag>
  );
}
