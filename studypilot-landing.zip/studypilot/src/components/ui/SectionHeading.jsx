import { cn } from "@/lib/cn.js";

export default function SectionHeading({ id, title, description, className = "" }) {
  return (
    <div className={cn("max-w-xl", className)}>
      <h2 id={id} className="text-2xl font-semibold tracking-tight text-ink sm:text-[32px] sm:leading-tight">
        {title}
      </h2>
      {description && <p className="mt-3 text-base leading-relaxed text-ink-muted sm:text-[17px]">{description}</p>}
    </div>
  );
}
