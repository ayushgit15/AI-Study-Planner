import { dashboardPreview as data } from "@/data/landingPreview.js";
import PreviewSidebar from "./PreviewSidebar.jsx";
import AdaptiveNotice from "./AdaptiveNotice.jsx";
import ExamCountdownCard from "./ExamCountdownCard.jsx";
import TodayProgressCard from "./TodayProgressCard.jsx";
import OverallCompletionCard from "./OverallCompletionCard.jsx";
import TodayTasksCard from "./TodayTasksCard.jsx";
import SubjectProgressCard from "./SubjectProgressCard.jsx";

/** A static, non-interactive picture of the dashboard, built from real components. */
export default function DashboardPreview() {
  return (
    <figure>
      <figcaption className="sr-only">
        Preview of the StudyPilot dashboard: 19 days until the next exam, 2 of 5 tasks done today, 42% of the plan
        complete, and progress for each subject.
      </figcaption>

      <div aria-hidden="true" className="overflow-hidden rounded-2xl border border-line bg-surface shadow-raised">
        <div className="flex h-9 items-center gap-1.5 border-b border-line px-4">
          <span className="size-2.5 rounded-full bg-line-strong" />
          <span className="size-2.5 rounded-full bg-line-strong" />
          <span className="size-2.5 rounded-full bg-line-strong" />
        </div>

        <div className="flex">
          <PreviewSidebar />

          <div className="min-w-0 flex-1 space-y-4 bg-canvas p-4 sm:p-6">
            <div>
              <p className="text-lg font-semibold tracking-tight">{data.greeting}</p>
              <p className="text-[13px] text-ink-muted">{data.dateLabel}</p>
            </div>

            <AdaptiveNotice {...data.notice} />

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <ExamCountdownCard {...data.exam} />
              <TodayProgressCard {...data.today} />
              <OverallCompletionCard {...data.overall} />
            </div>

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
              <div className="lg:col-span-3">
                <TodayTasksCard tasks={data.tasks} />
              </div>
              <div className="lg:col-span-2">
                <SubjectProgressCard subjects={data.subjects} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </figure>
  );
}
