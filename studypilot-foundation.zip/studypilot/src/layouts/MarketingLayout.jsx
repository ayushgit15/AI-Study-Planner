import { Outlet } from "react-router-dom";
import Logo from "@/components/ui/Logo.jsx";
import Button from "@/components/ui/Button.jsx";

/** Shell for public pages (landing). */
export default function MarketingLayout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4 sm:px-6 lg:px-10">
        <Logo />
        <div className="flex items-center gap-2">
          <Button to="/dashboard" variant="ghost" size="sm" className="hidden sm:inline-flex">
            Open dashboard
          </Button>
          <Button to="/onboarding" size="sm">
            Create study plan
          </Button>
        </div>
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="mx-auto w-full max-w-6xl px-4 py-8 text-sm text-ink-faint sm:px-6 lg:px-10">
        © 2026 StudyPilot
      </footer>
    </div>
  );
}
