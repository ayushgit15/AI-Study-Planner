import { RefreshCw } from "lucide-react";

export default function AdaptiveNotice({ title, message }) {
  return (
    <div className="flex items-start gap-3 rounded-card border border-accent/15 bg-accent-soft px-4 py-3">
      <span className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-accent text-white">
        <RefreshCw size={13} strokeWidth={2.5} />
      </span>
      <p className="text-[13px] leading-relaxed text-ink-muted">
        <span className="font-semibold text-ink">{title}. </span>
        {message}
      </p>
    </div>
  );
}
