import Container from "@/components/ui/Container.jsx";
import SectionHeading from "@/components/ui/SectionHeading.jsx";
import FeatureCard from "./FeatureCard.jsx";
import { features } from "@/data/landingContent.js";

export default function FeaturesSection() {
  return (
    <section id="features" aria-labelledby="features-title" className="scroll-mt-16 py-16 sm:py-24">
      <Container>
        <SectionHeading
          id="features-title"
          title="Planning that keeps up with your week"
          description="Everything in your plan comes from what you tell StudyPilot: when your exams are, how much time you have, and where you feel weak."
        />
        <div className="mt-10 grid gap-4 sm:mt-12 sm:gap-5 md:grid-cols-2">
          {features.map((feature) => (
            <FeatureCard key={feature.id} feature={feature} />
          ))}
        </div>
      </Container>
    </section>
  );
}
