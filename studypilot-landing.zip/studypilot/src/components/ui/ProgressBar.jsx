import { cn } from "@/lib/cn.js";

const tones = {
  accent: "bg-accent",
  success: "bg-success",
  warning: "bg-warning",
};

/** Thin horizontal progress bar. `value` is 0–100. */
export default function ProgressBar({ value, tone = "accent", delay = 0, animated = true, className = "" }) {
  return (
    <div
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={value}
      className={cn("h-1.5 w-full overflow-hidden rounded-full bg-line", className)}
    >
      <div
        className={cn("h-full origin-left rounded-full", tones[tone], animated && "animate-grow-x")}
        style={{ width: `${value}%`, animationDelay: `${delay}ms` }}
      />
    </div>
  );
}
