import { CalendarDays, LayoutDashboard, Settings, TrendingUp } from "lucide-react";

export const appNavItems = [
  { label: "Dashboard", to: "/dashboard", icon: LayoutDashboard },
  { label: "Study plan", to: "/study-plan", icon: CalendarDays },
  { label: "Progress", to: "/progress", icon: TrendingUp },
  { label: "Settings", to: "/settings", icon: Settings },
];
