import { ArrowRight } from "lucide-react";
import Button from "@/components/ui/Button.jsx";

// Placeholder hero. The real landing page is built in its own step.
export default function LandingPage() {
  return (
    <section className="mx-auto w-full max-w-6xl px-4 pb-24 pt-16 sm:px-6 sm:pt-24 lg:px-10">
      <h1 className="max-w-2xl text-4xl font-semibold leading-[1.1] tracking-tight text-ink sm:text-5xl">
        A study plan that adjusts when you fall behind.
      </h1>
      <p className="mt-5 max-w-lg text-lg leading-relaxed text-ink-muted">
        Tell StudyPilot your exam dates and how confident you feel about each topic. It plans your weeks, and
        re-plans when you miss a session.
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        <Button to="/onboarding" size="lg">
          Create study plan
          <ArrowRight size={18} aria-hidden="true" />
        </Button>
        <Button to="/dashboard" variant="secondary" size="lg">
          See a sample dashboard
        </Button>
      </div>
    </section>
  );
}
