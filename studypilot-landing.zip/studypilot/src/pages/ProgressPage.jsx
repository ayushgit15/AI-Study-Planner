import PageHeader from "@/components/layout/PageHeader.jsx";
import PagePlaceholder from "@/components/layout/PagePlaceholder.jsx";

export default function ProgressPage() {
  return (
    <>
      <PageHeader
        title="Progress"
        description="How your study time and topic confidence are trending."
      />
      <PagePlaceholder />
    </>
  );
}
