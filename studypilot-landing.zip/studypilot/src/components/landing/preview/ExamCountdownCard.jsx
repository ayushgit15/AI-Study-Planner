import { CalendarClock } from "lucide-react";
import PreviewCard from "./PreviewCard.jsx";

export default function ExamCountdownCard({ days, subject, dateLabel, next }) {
  return (
    <PreviewCard title="Exam countdown" action={<CalendarClock size={15} className="text-ink-faint" />}>
      <p className="text-3xl font-semibold leading-none tracking-tight tabular-nums">
        {days}
        <span className="ml-1.5 text-sm font-medium text-ink-muted">days</span>
      </p>
      <p className="mt-2.5 text-[13px] font-medium">{subject}</p>
      <p className="text-xs text-ink-muted">{dateLabel}</p>
      <p className="mt-auto pt-3 text-xs text-ink-faint">{next}</p>
    </PreviewCard>
  );
}
