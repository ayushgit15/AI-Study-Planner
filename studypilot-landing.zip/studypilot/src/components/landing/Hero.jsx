import Container from "@/components/ui/Container.jsx";
import Button from "@/components/ui/Button.jsx";
import FadeUp from "@/components/ui/FadeUp.jsx";

export default function Hero() {
  return (
    <section className="pb-12 pt-14 sm:pb-16 sm:pt-24">
      <Container>
        <div className="max-w-3xl">
          <FadeUp as="h1" className="text-4xl font-semibold leading-[1.08] tracking-tight sm:text-5xl lg:text-[56px]">
            Your study plan should adapt to you.
          </FadeUp>
          <FadeUp
            as="p"
            delay={80}
            className="mt-5 max-w-xl text-base leading-relaxed text-ink-muted sm:text-lg"
          >
            StudyPilot builds a personalized study plan around your exam date, available time, strengths, and weak
            areas — then adapts as you progress.
          </FadeUp>
          <FadeUp delay={160} className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button to="/onboarding" size="lg">
              Create My Study Plan
            </Button>
            <Button to="/dashboard" variant="secondary" size="lg">
              Explore Demo
            </Button>
          </FadeUp>
        </div>
      </Container>
    </section>
  );
}
