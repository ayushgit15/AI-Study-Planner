import { LogoMark } from "@/components/ui/Logo.jsx";
import { appNavItems } from "@/data/navigation.js";
import { mockUser } from "@/data/mockUser.js";
import { cn } from "@/lib/cn.js";

/** Static miniature of the app sidebar. Shown from the lg breakpoint up. */
export default function PreviewSidebar() {
  return (
    <div className="hidden w-48 shrink-0 flex-col border-r border-line bg-surface p-4 lg:flex">
      <div className="flex items-center gap-2 px-1">
        <LogoMark size={22} />
        <span className="text-sm font-semibold tracking-tight">StudyPilot</span>
      </div>

      <ul className="mt-6 flex flex-1 flex-col gap-0.5">
        {appNavItems.map(({ label, icon: Icon }, index) => (
          <li
            key={label}
            className={cn(
              "flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] font-medium",
              index === 0 ? "bg-accent-soft text-accent" : "text-ink-muted",
            )}
          >
            <Icon size={16} />
            {label}
          </li>
        ))}
      </ul>

      <div className="flex items-center gap-2 border-t border-line pt-3">
        <span className="flex size-7 items-center justify-center rounded-full bg-accent-soft text-[11px] font-semibold text-accent">
          {mockUser.initials}
        </span>
        <span className="truncate text-xs font-medium">{mockUser.name}</span>
      </div>
    </div>
  );
}
