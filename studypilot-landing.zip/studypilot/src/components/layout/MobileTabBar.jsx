import { NavLink } from "react-router-dom";
import { appNavItems } from "@/data/navigation.js";
import { cn } from "@/lib/cn.js";

export default function MobileTabBar() {
  return (
    <nav
      aria-label="Main"
      className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-4 border-t border-line bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden"
    >
      {appNavItems.map(({ label, to, icon: Icon }) => (
        <NavLink
          key={to}
          to={to}
          className={({ isActive }) =>
            cn(
              "flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium transition-colors duration-150",
              isActive ? "text-accent" : "text-ink-faint hover:text-ink",
            )
          }
        >
          <Icon size={20} aria-hidden="true" />
          {label}
        </NavLink>
      ))}
    </nav>
  );
}
