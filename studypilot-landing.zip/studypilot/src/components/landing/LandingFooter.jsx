import Container from "@/components/ui/Container.jsx";
import { landingNavLinks } from "@/data/landingContent.js";

export default function LandingFooter() {
  return (
    <footer className="border-t border-line">
      <Container className="flex flex-col gap-4 py-8 text-sm text-ink-muted sm:flex-row sm:items-center sm:justify-between">
        <p>© 2026 StudyPilot</p>
        <nav aria-label="Footer" className="flex gap-5">
          {landingNavLinks.map((link) => (
            <a key={link.href} href={link.href} className="transition-colors hover:text-ink">
              {link.label}
            </a>
          ))}
        </nav>
      </Container>
    </footer>
  );
}
