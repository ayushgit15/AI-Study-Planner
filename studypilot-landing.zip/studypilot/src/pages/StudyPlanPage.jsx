import PageHeader from "@/components/layout/PageHeader.jsx";
import PagePlaceholder from "@/components/layout/PagePlaceholder.jsx";

export default function StudyPlanPage() {
  return (
    <>
      <PageHeader
        title="Study plan"
        description="Your schedule for the weeks ahead, adjusted as you go."
      />
      <PagePlaceholder />
    </>
  );
}
