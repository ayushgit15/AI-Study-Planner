import Logo from "@/components/ui/Logo.jsx";

export default function MobileTopBar() {
  return (
    <div className="sticky top-0 z-20 flex h-14 items-center border-b border-line bg-surface/90 px-4 backdrop-blur lg:hidden">
      <Logo to="/dashboard" />
    </div>
  );
}
