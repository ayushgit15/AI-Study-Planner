import { cn } from "@/lib/cn.js";

/** Standard page width and horizontal padding. */
export default function Container({ as: Tag = "div", className = "", children, ...props }) {
  return (
    <Tag className={cn("mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-10", className)} {...props}>
      {children}
    </Tag>
  );
}
