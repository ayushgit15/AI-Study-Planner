import { Check } from "lucide-react";
import PreviewCard from "./PreviewCard.jsx";
import { cn } from "@/lib/cn.js";

function TaskRow({ task }) {
  const isDone = task.status === "done";
  const isNext = task.status === "next";

  return (
    <li className={cn("flex items-center gap-3 rounded-lg px-2 py-2", isNext && "bg-accent-soft")}>
      <span
        className={cn(
          "flex size-5 shrink-0 items-center justify-center rounded-md border",
          isDone ? "border-accent bg-accent text-white" : "border-line-strong bg-surface",
        )}
      >
        {isDone && <Check size={12} strokeWidth={3} />}
      </span>

      <div className="min-w-0 flex-1">
        <p className={cn("truncate text-[13px] font-medium", isDone && "text-ink-faint line-through")}>{task.title}</p>
        <p className="flex items-center gap-2 text-xs text-ink-muted">
          <span className="truncate">{task.subject}</span>
          {isNext && (
            <span className="shrink-0 rounded-full bg-accent px-1.5 py-px text-[10px] font-medium text-white">Up next</span>
          )}
        </p>
      </div>

      <div className="shrink-0 text-right">
        <p className="text-xs font-medium tabular-nums">{task.time}</p>
        <p className="text-xs text-ink-muted tabular-nums">{task.minutes} min</p>
      </div>
    </li>
  );
}

export default function TodayTasksCard({ tasks }) {
  return (
    <PreviewCard title="Today's tasks" action={<span className="text-xs text-ink-faint">{tasks.length} tasks</span>}>
      <ul className="-mx-1 space-y-0.5">
        {tasks.map((task) => (
          <TaskRow key={task.id} task={task} />
        ))}
      </ul>
    </PreviewCard>
  );
}
