import PreviewCard from "./PreviewCard.jsx";
import ProgressBar from "@/components/ui/ProgressBar.jsx";
import { cn } from "@/lib/cn.js";

function SubjectRow({ subject, index }) {
  const isBehind = subject.status === "behind";

  return (
    <li>
      <div className="flex items-baseline justify-between gap-2 text-[13px]">
        <span className="truncate font-medium">{subject.name}</span>
        <span className="tabular-nums text-ink-muted">{subject.percent}%</span>
      </div>
      <ProgressBar
        value={subject.percent}
        tone={isBehind ? "warning" : "accent"}
        delay={600 + index * 80}
        className="mt-1.5"
      />
      <p className={cn("mt-1.5 text-xs", isBehind ? "font-medium text-warning" : "text-ink-muted")}>
        {isBehind ? `Behind schedule, exam ${subject.examDate}` : `Exam ${subject.examDate}`}
      </p>
    </li>
  );
}

export default function SubjectProgressCard({ subjects }) {
  return (
    <PreviewCard title="Subject progress">
      <ul className="space-y-4">
        {subjects.map((subject, index) => (
          <SubjectRow key={subject.name} subject={subject} index={index} />
        ))}
      </ul>
    </PreviewCard>
  );
}
