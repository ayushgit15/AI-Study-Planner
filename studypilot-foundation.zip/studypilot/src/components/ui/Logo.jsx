import { Link } from "react-router-dom";

export default function Logo({ to = "/", className = "" }) {
  return (
    <Link to={to} className={`inline-flex items-center gap-2.5 ${className}`} aria-label="StudyPilot home">
      <svg width="28" height="28" viewBox="0 0 32 32" aria-hidden="true">
        <rect width="32" height="32" rx="9" fill="var(--color-accent)" />
        <path d="M9 21.5 23 9l-4.2 14.2-3.6-4.6-4.4 1.8L9 21.5Z" fill="#fff" />
      </svg>
      <span className="text-[17px] font-semibold tracking-tight text-ink">StudyPilot</span>
    </Link>
  );
}
