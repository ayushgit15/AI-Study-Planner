import Container from "@/components/ui/Container.jsx";
import SectionHeading from "@/components/ui/SectionHeading.jsx";
import { howItWorksSteps } from "@/data/landingContent.js";

function StepItem({ number, step, isLast }) {
  return (
    <li className="relative flex gap-5 pb-10 last:pb-0">
      {!isLast && <span aria-hidden="true" className="absolute left-[17px] top-11 bottom-1 w-px bg-line-strong" />}
      <span className="relative flex size-9 shrink-0 items-center justify-center rounded-full border border-line-strong bg-surface text-sm font-semibold text-accent">
        {number}
      </span>
      <div className="pt-1">
        <h3 className="text-lg font-semibold tracking-tight">{step.title}</h3>
        <p className="mt-1.5 max-w-lg text-[15px] leading-relaxed text-ink-muted">{step.description}</p>
      </div>
    </li>
  );
}

export default function HowItWorksSection() {
  return (
    <section
      id="how-it-works"
      aria-labelledby="how-it-works-title"
      className="scroll-mt-16 border-y border-line bg-surface py-16 sm:py-24"
    >
      <Container className="grid gap-10 lg:grid-cols-[5fr_7fr] lg:gap-16">
        <SectionHeading
          id="how-it-works-title"
          title="How StudyPilot works"
          description="Three steps from your exam date to a schedule you can follow, and keep following."
          className="lg:sticky lg:top-28 lg:self-start"
        />
        <ol>
          {howItWorksSteps.map((step, index) => (
            <StepItem key={step.title} number={index + 1} step={step} isLast={index === howItWorksSteps.length - 1} />
          ))}
        </ol>
      </Container>
    </section>
  );
}
