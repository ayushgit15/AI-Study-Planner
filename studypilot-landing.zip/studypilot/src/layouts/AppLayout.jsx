import { Outlet, useLocation } from "react-router-dom";
import Sidebar from "@/components/layout/Sidebar.jsx";
import MobileTopBar from "@/components/layout/MobileTopBar.jsx";
import MobileTabBar from "@/components/layout/MobileTabBar.jsx";

/** Shell for the signed-in product: Dashboard, Study plan, Progress, Settings. */
export default function AppLayout() {
  const { pathname } = useLocation();

  return (
    <div className="min-h-dvh lg:pl-64">
      <Sidebar />
      <MobileTopBar />
      <main className="mx-auto w-full max-w-6xl px-4 pb-28 pt-6 sm:px-6 lg:px-10 lg:pb-16 lg:pt-10">
        {/* Keyed by path so each page fades in when you navigate */}
        <div key={pathname} className="animate-page-in">
          <Outlet />
        </div>
      </main>
      <MobileTabBar />
    </div>
  );
}
