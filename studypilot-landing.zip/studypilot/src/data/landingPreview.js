// Static mock data for the dashboard preview on the landing page.
// All numbers are kept consistent with each other (tasks, minutes, percentages).

export const dashboardPreview = {
  greeting: "Good morning, Aanya",
  dateLabel: "Saturday, 19 September",

  notice: {
    title: "Your plan was adjusted",
    message:
      "You missed Normalization practice on Friday. It's now on Tuesday, and Sunday's revision was shortened to fit.",
  },

  exam: {
    days: 19,
    subject: "Database Systems",
    dateLabel: "Thursday, 8 October",
    next: "Then Operating Systems on 12 Oct",
  },

  today: {
    tasksDone: 2,
    tasksTotal: 5,
    studied: "1h 25m",
    planned: "3h 30m",
  },

  overall: {
    percent: 42,
    hoursDone: 56,
    hoursTotal: 132,
    status: "On track",
  },

  tasks: [
    { id: 1, title: "Normalization: 2NF to BCNF", subject: "Database Systems", time: "9:00 AM", minutes: 45, status: "done" },
    { id: 2, title: "Process scheduling algorithms", subject: "Operating Systems", time: "10:00 AM", minutes: 40, status: "done" },
    { id: 3, title: "Transactions and ACID properties", subject: "Database Systems", time: "12:00 PM", minutes: 50, status: "next" },
    { id: 4, title: "Subnetting practice problems", subject: "Computer Networks", time: "4:00 PM", minutes: 45, status: "todo" },
    { id: 5, title: "Graph theory revision", subject: "Discrete Mathematics", time: "6:30 PM", minutes: 30, status: "todo" },
  ],

  subjects: [
    { name: "Database Systems", percent: 68, examDate: "8 Oct", status: "on-track" },
    { name: "Operating Systems", percent: 45, examDate: "12 Oct", status: "on-track" },
    { name: "Computer Networks", percent: 31, examDate: "15 Oct", status: "behind" },
    { name: "Discrete Mathematics", percent: 24, examDate: "19 Oct", status: "on-track" },
  ],
};
