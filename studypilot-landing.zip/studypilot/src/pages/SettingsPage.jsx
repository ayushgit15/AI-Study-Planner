import PageHeader from "@/components/layout/PageHeader.jsx";
import PagePlaceholder from "@/components/layout/PagePlaceholder.jsx";

export default function SettingsPage() {
  return (
    <>
      <PageHeader
        title="Settings"
        description="Study hours, preferences and account details."
      />
      <PagePlaceholder />
    </>
  );
}
