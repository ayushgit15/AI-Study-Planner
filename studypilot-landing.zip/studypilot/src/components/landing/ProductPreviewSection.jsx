import Container from "@/components/ui/Container.jsx";
import FadeUp from "@/components/ui/FadeUp.jsx";
import DashboardPreview from "./preview/DashboardPreview.jsx";

export default function ProductPreviewSection() {
  return (
    <section aria-label="Product preview" className="pb-8 sm:pb-12">
      <Container>
        <FadeUp delay={260}>
          <DashboardPreview />
        </FadeUp>
      </Container>
    </section>
  );
}
