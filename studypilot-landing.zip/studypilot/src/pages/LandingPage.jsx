import Hero from "@/components/landing/Hero.jsx";
import ProductPreviewSection from "@/components/landing/ProductPreviewSection.jsx";
import FeaturesSection from "@/components/landing/FeaturesSection.jsx";
import HowItWorksSection from "@/components/landing/HowItWorksSection.jsx";
import FinalCta from "@/components/landing/FinalCta.jsx";

export default function LandingPage() {
  return (
    <>
      <Hero />
      <ProductPreviewSection />
      <FeaturesSection />
      <HowItWorksSection />
      <FinalCta />
    </>
  );
}
