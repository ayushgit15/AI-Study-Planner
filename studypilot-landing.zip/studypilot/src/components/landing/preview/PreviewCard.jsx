import Card from "@/components/ui/Card.jsx";
import { cn } from "@/lib/cn.js";

/** Small titled card used inside the dashboard preview. */
export default function PreviewCard({ title, action, className = "", children }) {
  return (
    <Card padding="sm" className={cn("flex h-full flex-col", className)}>
      <div className="mb-3 flex items-center justify-between gap-2">
        <h3 className="text-xs font-medium text-ink-muted">{title}</h3>
        {action}
      </div>
      {children}
    </Card>
  );
}
