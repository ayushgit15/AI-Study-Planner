import { ArrowDown } from "lucide-react";
import { cn } from "@/lib/cn.js";

// Small illustrations shown at the bottom of each feature card.
// Each takes the props from the matching `visual` entry in data/landingContent.js.

function InputsVisual({ chips }) {
  return (
    <div className="flex flex-wrap gap-2">
      {chips.map((chip) => (
        <span
          key={chip.label}
          className="inline-flex items-center gap-1.5 rounded-full border border-line bg-surface px-3 py-1.5 text-xs"
        >
          <span className="text-ink-muted">{chip.label}</span>
          <span className="font-medium text-ink">{chip.value}</span>
        </span>
      ))}
    </div>
  );
}

const tagTones = {
  danger: "bg-danger-soft text-danger",
  accent: "bg-accent-soft text-accent",
};

function TaskPill({ title, when, tag, tone }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-line bg-surface px-3 py-2.5">
      <div className="min-w-0">
        <p className="truncate text-[13px] font-medium">{title}</p>
        <p className="text-xs text-ink-muted">{when}</p>
      </div>
      <span className={cn("shrink-0 rounded-full px-2 py-0.5 text-[11px] font-medium", tagTones[tone])}>{tag}</span>
    </div>
  );
}

function RescheduleVisual({ from, to }) {
  return (
    <div className="flex flex-col items-stretch gap-1.5">
      <TaskPill {...from} />
      <ArrowDown size={14} className="self-center text-ink-faint" aria-hidden="true" />
      <TaskPill {...to} />
    </div>
  );
}

const levelStyles = {
  High: "bg-accent text-white",
  Medium: "bg-accent-soft text-accent",
  Low: "bg-line text-ink-muted",
};

function PrioritiesVisual({ items }) {
  return (
    <ul className="space-y-2">
      {items.map((item) => (
        <li
          key={item.topic}
          className="flex items-center justify-between gap-3 rounded-xl border border-line bg-surface px-3 py-2"
        >
          <div className="min-w-0">
            <p className="truncate text-[13px] font-medium">{item.topic}</p>
            <p className="truncate text-xs text-ink-muted">{item.note}</p>
          </div>
          <span className={cn("shrink-0 rounded-full px-2 py-0.5 text-[11px] font-medium", levelStyles[item.level])}>
            {item.level}
          </span>
        </li>
      ))}
    </ul>
  );
}

function WeeklyHoursVisual({ days, maxHours, caption }) {
  return (
    <div>
      <div className="flex h-24 items-end gap-2 sm:gap-3">
        {days.map((d, index) => (
          <div key={index} title={d.name} className="flex h-full flex-1 flex-col items-center justify-end gap-1.5">
            <div className="flex w-full flex-1 items-end justify-center">
              <div
                className="relative w-full max-w-6 overflow-hidden rounded-md bg-line"
                style={{ height: `${(d.planned / maxHours) * 100}%` }}
              >
                <div className="absolute inset-x-0 bottom-0 bg-accent" style={{ height: `${(d.done / d.planned) * 100}%` }} />
              </div>
            </div>
            <span className="text-[11px] text-ink-muted">{d.day}</span>
          </div>
        ))}
      </div>
      <p className="mt-3 flex items-center gap-3 text-xs text-ink-muted">
        <span>{caption}</span>
        <span className="inline-flex items-center gap-1.5">
          <span className="size-2 rounded-sm bg-accent" /> Done
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="size-2 rounded-sm bg-line-strong" /> Planned
        </span>
      </p>
    </div>
  );
}

const visuals = {
  inputs: InputsVisual,
  reschedule: RescheduleVisual,
  priorities: PrioritiesVisual,
  weekly: WeeklyHoursVisual,
};

export default function FeatureVisual({ visual }) {
  const { type, ...props } = visual;
  const Visual = visuals[type];
  return Visual ? <Visual {...props} /> : null;
}
