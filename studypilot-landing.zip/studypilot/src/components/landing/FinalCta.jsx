import { ArrowRight } from "lucide-react";
import Container from "@/components/ui/Container.jsx";
import Button from "@/components/ui/Button.jsx";

export default function FinalCta() {
  return (
    <section aria-labelledby="final-cta-title" className="py-16 sm:py-24">
      <Container>
        <div className="flex flex-col gap-8 rounded-card bg-accent px-6 py-10 sm:px-10 sm:py-12 md:flex-row md:items-center md:justify-between">
          <div className="max-w-lg">
            <h2 id="final-cta-title" className="text-2xl font-semibold tracking-tight text-white sm:text-[32px] sm:leading-tight">
              Ready to study smarter?
            </h2>
            <p className="mt-3 text-base leading-relaxed text-white/80 sm:text-[17px]">
              Add your exams and topics, and get a day-by-day plan you can start today.
            </p>
          </div>
          <Button to="/onboarding" variant="inverse" size="lg" className="shrink-0 self-start md:self-auto">
            Build My Plan
            <ArrowRight size={18} aria-hidden="true" />
          </Button>
        </div>
      </Container>
    </section>
  );
}
