import Card from "@/components/ui/Card.jsx";
import FeatureVisual from "./featureVisuals.jsx";

export default function FeatureCard({ feature }) {
  const { icon: Icon, title, description, visual } = feature;

  return (
    <Card
      as="article"
      padding="none"
      className="flex flex-col overflow-hidden transition-shadow duration-200 hover:shadow-raised"
    >
      <div className="p-6 sm:p-7">
        <span className="flex size-10 items-center justify-center rounded-control bg-accent-soft text-accent">
          <Icon size={20} aria-hidden="true" />
        </span>
        <h3 className="mt-5 text-lg font-semibold tracking-tight">{title}</h3>
        <p className="mt-2 text-[15px] leading-relaxed text-ink-muted">{description}</p>
      </div>

      <div className="mt-auto flex items-center md:min-h-52 border-t border-line bg-canvas/70 p-5 sm:px-7 sm:py-6">
        <div className="w-full">
          <FeatureVisual visual={visual} />
        </div>
      </div>
    </Card>
  );
}
