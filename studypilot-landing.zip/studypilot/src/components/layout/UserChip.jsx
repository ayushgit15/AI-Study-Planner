import { mockUser } from "@/data/mockUser.js";

export default function UserChip() {
  return (
    <div className="flex items-center gap-3">
      <span className="flex size-9 items-center justify-center rounded-full bg-accent-soft text-[13px] font-semibold text-accent">
        {mockUser.initials}
      </span>
      <div className="min-w-0">
        <p className="truncate text-sm font-medium text-ink">{mockUser.name}</p>
        <p className="truncate text-xs text-ink-faint">{mockUser.detail}</p>
      </div>
    </div>
  );
}
