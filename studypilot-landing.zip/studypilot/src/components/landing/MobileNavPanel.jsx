import { Link } from "react-router-dom";
import Container from "@/components/ui/Container.jsx";
import Button from "@/components/ui/Button.jsx";

/** Dropdown menu shown under the navbar on small screens. */
export default function MobileNavPanel({ id, links, onNavigate }) {
  return (
    <div id={id} className="animate-page-in border-t border-line bg-canvas md:hidden">
      <Container className="flex flex-col gap-1 py-4">
        {links.map((link) => (
          <a
            key={link.href}
            href={link.href}
            onClick={onNavigate}
            className="rounded-control px-3 py-3 text-[15px] font-medium text-ink hover:bg-black/5"
          >
            {link.label}
          </a>
        ))}
        {/* Auth isn't built yet, so Sign in goes to the demo dashboard for now. */}
        <Link
          to="/dashboard"
          onClick={onNavigate}
          className="rounded-control px-3 py-3 text-[15px] font-medium text-ink hover:bg-black/5"
        >
          Sign in
        </Link>
        <Button to="/onboarding" onClick={onNavigate} className="mt-3">
          Create Study Plan
        </Button>
      </Container>
    </div>
  );
}
