import PageHeader from "@/components/layout/PageHeader.jsx";
import PagePlaceholder from "@/components/layout/PagePlaceholder.jsx";

export default function DashboardPage() {
  return (
    <>
      <PageHeader
        title="Dashboard"
        description="Today's tasks, upcoming exams and a snapshot of your progress."
      />
      <PagePlaceholder />
    </>
  );
}
